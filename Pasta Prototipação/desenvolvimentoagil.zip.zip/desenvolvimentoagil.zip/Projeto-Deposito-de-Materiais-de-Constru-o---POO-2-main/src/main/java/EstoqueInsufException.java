//Lucas Raphael, 2525518 
public class EstoqueInsufException extends Exception {
    public EstoqueInsufException(String mensagem) {
        super(mensagem);
    }
}
