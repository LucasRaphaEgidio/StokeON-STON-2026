//Lucas Raphael, 2525518 

public class ClienteView {
    public String exibirDados(ClienteModel cliente) {
        String dadosPessoa = "Nome: " + cliente.getNome() + "\nCPF: " + cliente.getCpf();
        String dadosCliente = "\nID: " + cliente.getId() +
                (cliente.getVendedorResponsavel() != null ? "\nAtendido por: " + cliente.getVendedorResponsavel().getNome() : "");
        return dadosPessoa + dadosCliente;
    }
}