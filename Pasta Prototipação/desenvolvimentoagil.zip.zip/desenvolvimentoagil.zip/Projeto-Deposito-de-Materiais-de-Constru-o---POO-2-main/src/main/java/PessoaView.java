//Lucas Raphael, 2525518 

public class PessoaView {

    public String exibirDados(PessoaModel pessoa) {
        return "Nome: " + pessoa.getNome() + "\nCPF: " + pessoa.getCpf();
    }
}