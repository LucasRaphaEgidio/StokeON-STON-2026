//Lucas Raphael, 2525518 

public class FuncionarioView {
    public String exibirDados(FuncionarioModel funcionario) {
        return "Nome: " + funcionario.getNome() + "\nCPF: " + funcionario.getCpf() + "\nMatrícula: " + funcionario.getMatricula();
    }
}