//Lucas Raphael, 2525518 

public class PrecoInvalException extends Exception {
    public PrecoInvalException(String mensagem) {
        super(mensagem);
    }
}
