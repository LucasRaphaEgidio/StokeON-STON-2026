//Lucas Raphael, 2525518 

public interface Calculavel {
    public double calcular();
}
